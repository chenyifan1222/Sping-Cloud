package com.study.springbootrabbitmqdelay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqDelayApplicationTests {

    @Test
    void contextLoads() {
    }

}
