package com.study.dlconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DlConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
