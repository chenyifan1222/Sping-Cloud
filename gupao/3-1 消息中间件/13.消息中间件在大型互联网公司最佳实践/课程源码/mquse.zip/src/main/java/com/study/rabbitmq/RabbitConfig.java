package com.study.rabbitmq;

/**
 * @Auther: allen
 * @Date: 2019/2/27 11:57
 */
public class RabbitConfig {

    public final static String HOST = "47.106.202.10";
    public final static int PORT = 5672;
    public final static String USERNAME = "guest";
    public final static String PASSWORD = "guest";

}
