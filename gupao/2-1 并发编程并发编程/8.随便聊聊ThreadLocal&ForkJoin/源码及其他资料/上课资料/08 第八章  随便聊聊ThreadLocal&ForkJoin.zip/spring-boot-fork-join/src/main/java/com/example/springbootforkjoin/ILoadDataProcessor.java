package com.example.springbootforkjoin;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2082233439
 * http://www.gupaoedu.com
 **/
public interface ILoadDataProcessor {


    /**
     * 加载对应的数据
     * @param context
     */
    void load(Context context);
}
