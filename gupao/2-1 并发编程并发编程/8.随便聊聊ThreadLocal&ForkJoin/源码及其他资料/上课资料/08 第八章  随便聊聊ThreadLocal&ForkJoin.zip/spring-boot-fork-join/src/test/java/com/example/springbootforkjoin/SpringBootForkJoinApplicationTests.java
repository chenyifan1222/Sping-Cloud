package com.example.springbootforkjoin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootForkJoinApplicationTests {

    @Test
    void contextLoads() {
    }

}
