package com.example.springbootforkjoin.pojo;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2082233439
 * http://www.gupaoedu.com
 * 销售信息
 **/

public class Seller {
    private int totalNum;
    private int sellerNum;

    public int getTotalNum() {
        return totalNum;
    }

    public void setTotalNum(int totalNum) {
        this.totalNum = totalNum;
    }

    public int getSellerNum() {
        return sellerNum;
    }

    public void setSellerNum(int sellerNum) {
        this.sellerNum = sellerNum;
    }
}
